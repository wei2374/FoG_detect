clear
close all
clc

%% Initialization:

% Maxon DCX19S (24V version):
beta = 0.7e-6;        % Friction coefficient found heuristically (DO NOT CHANGE)

% ...
% TODO (T.1.1): complete with the required model parameters you find on the
%% data-sheet
J = 264e-7; %Rotor Inertia
K_t = 68e-3; %Torque Constant
R = 0.119/2; %Rotor winding Resistance
L = 0.149e-3/2; %Rotor winding Inductance
K_v = 140*2*pi/60;% Velocity Constant
K_e = 1/K_v;
t_s = 13800e-3;
P=16/4;

% TODO (T.1.1): complete with the state space DC-motor model:
%% state
A_bldc = [0,P/2,0,0,0;
        0,-beta/J,0,0,0;
        0,0,-R/L,0,0;
        0,0,0,-R/L,0;
        0,0,0,0,-R/L];
    
B_bldc = [0,0,0,0;
           -1/J,0,0,0;
           0,-1/L,0,0;
           0,0,-1/L,0;
           0,0,0,-1/L];

%% Main simulation loop:

% Function handle for dynamic simulation:
DCmotorDynamics = @(State, controlInput,A_dc) bldcMotorDynamics(State, controlInput, A_dc, B_bldc);

%% T1.2
dt = 1e-6; % Timestamp of the simulator [s]
finalTime = 1.0; % Final time of the simulation [s]
simulationTime = linspace(0,finalTime,finalTime/dt+1);
numEpochs = numel(simulationTime);
x_k = zeros(5,numEpochs); % State       

%% 1 Va=Vb=Vc=0V,t_load=ts,sine
%{
u(1,:) = simulationTime*0 + t_s;
u(2,:) = simulationTime*0;
u(3,:) = simulationTime*0;
u(4,:) = simulationTime*0;
method='sine';
%}
%% 2 Va=Vb=Vc=0V,t_load=t_s,trapzoidal
%{
u(1,:) = simulationTime*0 + t_s;
u(2,:) = simulationTime*0;
u(3,:) = simulationTime*0;
u(4,:) = simulationTime*0;
method='trap';
%}
%% 3 sine input voltage, t_load = ts, sine 

u(1,:) = simulationTime*0 + t_s;
u(2,:) = 12*sin(simulationTime*10*2*pi);
u(3,:) = 12*sin(simulationTime*10*2*pi+2*pi/3);
u(4,:) = 12*sin(simulationTime*10*2*pi+4*pi/3);
method='sine';

%% 4 sine input voltage, t_load = ts, trapzoidal 
%{
u(1,:) = simulationTime*0 + t_s;
u(2,:) = 12*sin(simulationTime*10*2*pi);
u(3,:) = 12*sin(simulationTime*10*2*pi+2*pi/3);
u(4,:) = 12*sin(simulationTime*10*2*pi+4*pi/3);
method='trap';
%}

%% 4 PWM V_r 100Hz
%%

for simulationEpoch = 2:numEpochs
    % TODO (T.1.1): Call the dynamic simulation routine here and fill the
    % required data fields
    theta = x_k(1,simulationEpoch);
    A_bldc(2,3) = BEMF_A(theta,method)*K_t/J;
    A_bldc(2,4) = BEMF_B(theta,method)*K_t/J;
    A_bldc(2,5) = BEMF_C(theta,method)*K_t/J;
    A_bldc(3,2) = -BEMF_A(theta,method)/(L*K_v);
    A_bldc(4,2) = -BEMF_B(theta,method)/(L*K_v);
    A_bldc(5,2) = -BEMF_C(theta,method)/(L*K_v);
    
    x_k(:,simulationEpoch+1) = rk4_IntegrationStep(DCmotorDynamics,x_k(:,simulationEpoch),u(:,simulationEpoch),A_bldc,dt);    

    ea(simulationEpoch) = K_e*BEMF_A(theta,method)*x_k(2,simulationEpoch);
    eb(simulationEpoch) = K_e*BEMF_B(theta,method)*x_k(2,simulationEpoch);
    ec(simulationEpoch) = K_e*BEMF_C(theta,method)*x_k(2,simulationEpoch);
    
    fa = BEMF_A(theta,method);
    fb = BEMF_B(theta,method);
    fc = BEMF_C(theta,method);
    
    torque(simulationEpoch) = K_t*(fa*x_k(3,simulationEpoch)+fb*x_k(4,simulationEpoch)+fc*x_k(5,simulationEpoch));
end


%% Plot Functions:

% TODO (T.1.2): plot the required quantities
figure(1)
subplot(2,2,1)
stairs(simulationTime,x_k(3,1:end-1),'-b');
hold on
stairs(simulationTime,x_k(4,1:end-1),'-r');
hold on
stairs(simulationTime,x_k(5,1:end-1),'-g');
hold on
title('ia ib ic');


subplot(2,2,2)
stairs(simulationTime,x_k(2,1:end-1)*60/(2*pi));
title('velocity w');


subplot(2,2,3)
stairs(simulationTime,ea(1:end),'-b');
hold on
stairs(simulationTime,eb(1:end),'-r');
hold on
stairs(simulationTime,ec(1,1:end),'-g');
hold on
title('ea eb ec');


subplot(2,2,4)
stairs(simulationTime,torque(1,1:end));
title('torque');
hold off


%% Simulation Routines:

function xdot_k = bldcMotorDynamics(x_km1, u_km1, A, B)
% TODO (T.1.1.1)
xdot_k = A*x_km1+B*u_km1;
end

function noisyState = noisyMeasurement(State, sd)

% This function adds Gaussian noise with a standard deviation sd to the measured quantity.

noisyState = State + diag(sd)*randn(size(State));

end

function x_next = rk4_IntegrationStep(ode_fun,x,u,A,h)

% Runge-Kutta RK4 integration step. ode_fun is a function handle.

k1 = ode_fun(x,u,A);
k2 = ode_fun(x+h/2.*k1,u,A);
k3 = ode_fun(x+h/2.*k2,u,A);
k4 = ode_fun(x+h.*k3,u,A);
x_next = x + h/6.*(k1+2*k2+2*k3+k4);

end


%% BEMF Functions:
function fa = BEMF_A(theta,method)
    if(method=='sine')
        fa = sin(theta);
    else
        theta=mod(theta,2*pi);
        if(theta>=0 &&theta<pi/6 )
            fa=1;
        elseif(theta>=pi/6 &&theta<3*pi/6 )
            fa=2-6*theta/pi;
        elseif(theta>=3*pi/6 &&theta<7*pi/6 )
            fa=-1;
        elseif(theta>=7*pi/6 &&theta<9*pi/6 )
            fa=6*theta/pi-8;
        elseif(theta>=9*pi/6 &&theta<12*pi/6)
            fa=1;
        end
    end
end

function fb = BEMF_B(theta,method)
    if(method=='sine')
        fb = sin(theta+2*pi/3);
    else
        theta=mod(theta,2*pi);
        if(theta>=0 &&theta<3*pi/6 )
            fb=-1;
        elseif(theta>=pi*3/6 &&theta<5*pi/6 )
            fb=6*theta/pi-4;
        elseif(theta>=5*pi/6 &&theta<9*pi/6 )
            fb=1;
        elseif(theta>=9*pi/6 &&theta<11*pi/6 )
            fb=-6*theta/pi+10;
        elseif(theta>=11*pi/6 &&theta<12*pi/6)
            fb=-1;
        end
    end
end

function fc = BEMF_C(theta,method)
    if(method=='sine')
        fc = sin(theta+4*pi/3);
    else
        theta=mod(theta,2*pi);
        if(theta>=0 &&theta<pi/6 )
            fc=6*theta/pi;
        elseif(theta>=pi/6 &&theta<5*pi/6 )
            fc=1;
        elseif(theta>=5*pi/6 &&theta<7*pi/6 )
            fc=6-6*theta/pi;
        elseif(theta>=7*pi/6 &&theta<11*pi/6 )
            fc=-1;
        elseif(theta>=11*pi/6 &&theta<12*pi/6)
            fc=6*theta/pi-12;
        end
    end
end
