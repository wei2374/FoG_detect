# SimulatorMatlab

## T.1.1.1 
* zero input voltage, stall load torque and sinusoidal BEMF can be configured by uncommenting line 50-54
* Observation: peak current value reaches 200A in the beginning, then ia,ib and ic stable as sine wave with pi/3 delay and 150A amptitude. The frequency is 40Hz.

peak reverse voltage value reaches 20V in the beginning, then ea,eb and ec stable as sine wave with pi/3 delay and 9V amptitude. The frequency is 40Hz.

rotation velocity stables at -1250rpm and torque stables at stall torque.

frequency of i and e can be find as w/p

## T.1.1.2
* zero input voltage, stall load torque and trapezoidal BEMF can be configured by uncommenting line 58-62

* Observation: peak current value reaches 145A in the beginning, then ia,ib and ic stable as sine wave with pi/3 delay with amptitude 100A. The frequency is 40Hz.

peak reverse voltage value reaches 18V in the beginning, then ea,eb and ec stable as trapezoidal wave with pi/3 delay with amptitude 7V. The frequency is 40Hz.

rotation velocity stables with oscillation at -750rpm and torque stables with oscillation at stall torque.

It can be observed that trapzoidal BEMF generates less peak current and voltage, but with less accurate torque and speed.


## T.1.1.3
* sine input voltage, stall load torque and sinusoidal BEMF can be configured by uncommenting line 66-70

* Observation: peak current value reaches 250A in the beginning, then ia,ib and ic stable as sine wave with pi/3 delay with amptitude 170A. The frequency is 10Hz.

peak reverse voltage value reaches 33V in the beginning, then ea,eb and ec stable as sine wave with pi/3 delay with amptitude 2V. The frequency is 10Hz.

rotation velocity stables at 300rpm and torque stables at stall torque.


## T.1.1.4
* sine input voltage, stall load torque and trapzoidal BEMF can be configured by uncommenting line 74-78

* Observation: peak current value reaches 250A in the beginning, then ia,ib and ic stable as sine wave with pi/3 delay with amptitude 165A. The frequency is 10Hz.

peak reverse voltage value reaches 26V in the beginning, then ea,eb and ec stable as trapezoidal wave with pi/3 delay with amptitude 2V. The frequency is 10Hz.

rotation velocity stables with ripple at 300rpm and torque stables with ripple at stall torque.

