% Compute the gain and the offset of the magnetometer
%
%   [M,w,R,G] = magCalib(mag)
%
%   mag: 3 x N matrix containing the magnetometer measurements for the
%           calibration
%
%   M:  gain matrix, 3 x 3
%   w:  offset, 3 x 1
%   R:  rotation matrix (normalized matrix), 3 x 3
%   G:  gain matrix (diagonal matrix), 3 x 3
%
function [M,w,R,G] = magCalib(mag)

mx = mag(1,:);
my = mag(2,:);
mz = mag(3,:);

G = eye(3);
R = eye(3);

w = zeros(3,1);

%??????????????????????????????????????????????????????????????????????????
%   Implement the ellipsoid fitting algorthm which finally delivers w, R,
%   and G.

%   M is the model matrix and describes the transformation of the
%   uncalibrated magnetometer measurement to the unit sphere. The
%   cooridnate system of the elliposid is not necessarily alligned to the
%   coordinate system of the magnetometer, i.e. R is usually not an
%   identiy matrix. R can later be used to transform the calibrated
%   measurements back to the coordinate system of the magnetometer.

%% 1) Ellipsoid Fitting find ellipsoid parameters (ellipsoid)
% In this step we try to find an ellipsoid(with gain and offset) which best describe the
% measurements

% Construct measurement matrix
len = length(mag);
for n=1:len
    m(n,:) = [mx(n)^2,my(n)^2,mz(n)^2,2*mx(n)*my(n),2*mz(n)*mx(n),2*mz(n)*my(n),2*mx(n),2*my(n),2*mz(n)];
end

% using least square error ellipsoid fitting to get ellipsoid paramaters
d = ones(len,1);
p = inv(m'*m)*m'*d;

A = p(1);
B = p(2);
C = p(3);
D = p(4);
E = p(5);
F = p(6);
G = p(7);
H = p(8);
K = p(9);

% we find ellipsoid paramaters with offset
% X^TA_1X + B_1^TX = 1
A_1 = [A D E;D B F;E F C];
B_1 = [2*G;2*H;2*K];

%% 2) Find Ellipsoid Offeset w (ellipsoid with center at original point)
% Since we want to find a perfect circle which has center at origininal point,
% we need to move the constructed ellipsoid to origininal point 
% we want to get parameter of (x-w)^T A (x-w) = 1
% which can be written as x^TAx - 2w^TAx = 1-w^TAw
% comparing with X^TA_1X + B_1^TX = 1 we can find the offset w 

w = -0.5*inv(A_1'*A_1)*A_1'*B_1;

%% 3) Find general ellipsoid matrix (ellipsoid with center at original point)
% Next, we need to find A in  (x-w)^T A (x-w) = 1
% In the first step we fitted the measurement into ellipsoid: X^TA_1X + B_1^TX = 1
% It can be written as  X^TA_2X + 2*B_2^TX -1 = 0
% with A_2 = A_1, B_2 = 0.5*B_1, this form is more convenient since we can
% use homogeneous coordinates change x_raw to x_= [x_raw;1]
% Then the equation can transform into a matrix form : x_1^T[A,b;b^T,-1]x_1=0

% Considering we could move the measurement with offset we calculated in
% step2, we apply another homogeneous transform to raw measurement x_2 = (I,w;0,1)(x_1-w) 
% x_2^T A_2 x_2 = 0
% (x_1-w)^T(I,w;0,1)^T A_2 (I,w;0,1)(x_1-w) = 0

% compare it with (x-w)^T A (x-w) = 1
% We can find A

B_2 = 0.5*B_1;
c=-1;
A_2 = [A_1,B_2;B_2',c];
I = eye(3);
T = [I,w;0 0 0 1];
A_3 = T'*A_2*T;
A_fit = (-1/A_3(4,4))*A_3(1:3,1:3);

%% 4) Find model matrix (sphere with center at original point)
% Now we find all parameters need in (x-w)^T A (x-w) = 1

% Since we want to calibrate it to a perfect sphere we need to transform it
% into X^T I X = 1

% So we apply singular value decomposition to A we can get A = U sigma V^T ,since
% A is a symmetric matrix, we have U=V;
%  (x-w)^T A (x-w) = 1
%  (x-w)^T U^T Sigma U (x-w) = 1
%  (x-w)^T U^T sqrt(Sigma) I sqrt(Sigma) U (x-w) = 1
%  X =  sqrt(Sigma) U (x-w);
%  sqrt(Sigma) is the gain to adjust 
%  w is the offeset need to compensate
%  U represent the rotation needs to be done.

[U,sigma,V] = svd(A_fit); 
R = U';
G = sqrt(sigma);


%??????????????????????????????????????????????????????????????????????????

M = G*R;


end