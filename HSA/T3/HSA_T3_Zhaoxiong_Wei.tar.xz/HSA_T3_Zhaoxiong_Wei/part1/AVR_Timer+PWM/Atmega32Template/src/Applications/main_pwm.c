// Get register definitions with auto complete in Qt Creator
#include <atmega32/io.h>

// For delay functions: F_CPU has to be defined
#include <util/delay.h>

#include <avr/interrupt.h>


ISR(TIMER0_OVF_vect) {
        PORTC|=1<<PC0;//turn on the portc
}

ISR(TIMER0_COMP_vect) {
        PORTC&=~(1<<PC0);//turn off the portc
}




int main (void)
{

    cli();//disable the interrupt
    DDRC |= 1<<PC0; // Configuring PC0 as Output
    TCCR0 |= (1<<CS02) |(1<<CS00);  // Timer mode with 1024 prescler
    TIMSK |= (1 << TOIE0)|(1 << OCIE0) ;   // Enable timer2 overflow interrupt(TOIE0) and output compare interrupt enable
    TCNT0 = 0x00; //Initialize the timer2 counter register to 0
    OCR0 = 0xe0;
    sei(); //enable the interrupt
    while(1)
    {}
    // Should never be reached
    return 0;
}
