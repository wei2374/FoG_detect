// Get register definitions with auto complete in Qt Creator
#include <atmega32/io.h>

// For delay functions: F_CPU has to be defined
#include <util/delay.h>

#include <avr/interrupt.h>

volatile int counter = 0;

ISR(TIMER2_OVF_vect) {
    if(counter==61)//1M/64/256 =
    {
        PORTC=PORTC ^ 0x01;//toggle the portc
        counter = 0;
    }
    else {

        counter++;
    }

}


int main (void)
{

    cli();//disable the interrupt
    DDRC |= 1<<PC0; // Configuring PC0 as Output
    TCCR2 |= (1<<CS22);;  // Timer mode with 64 prescler
    TIMSK |= (1 << TOIE2) ;   // Enable timer2 overflow interrupt(TOIE2)
    TCNT2 = 0x00; //Initialize the timer2 counter register to 0

    sei(); //enable the interrupt
    while(1)
    {}
    // Should never be reached
    return 0;
}
