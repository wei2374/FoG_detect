// Get register definitions with auto complete in Qt Creator
#include <atmega32/io.h>

// For delay functions: F_CPU has to be defined
#include <util/delay.h>

#include <avr/interrupt.h>

volatile uint8_t value=0;

//using the adc to read out the value of potentionmeter
ISR(ADC_vect)
{
    //PORTB|=1<<PB3;
    value =  ADCH;
    OCR0 = value;
    ADCSRA |= (1<<ADSC);
}

void init_adc()
{
    //configure AVCC 5V as AREF
    ADMUX |= (1<<REFS0);
    //prescaler of 128, ADPS0=ADPS1=ADPS2=1
    ADCSRA |= (1<<ADPS0)|(1<<ADPS1)|(1<<ADPS2);
    //8 bit precision, left adjusted
    ADMUX |= (1<<ADLAR);
    // Enable ADC Interrupt
    ADCSRA |= (1 << ADIE);
    //enable ADC
    ADCSRA |= (1<<ADEN);
}


int main (void)
{

    cli();//disable the interrupt
    DDRB |= 1<<PB3; // Configuring PC0 as Output

    TCCR0 |= (1 << WGM01) | (1 << WGM00)|(1 << COM00)|(1 << COM01); //Fast PWM non-inverting mode
    TCCR0 |= (1<<CS02);  // Timer mode with 256 prescler
    //TIMSK = (1 << TOIE0)|(1 << OCIE0);   // Enable timer2 overflow interrupt(TOIE0) and output compare interrupt enable
    TCNT0 = 0x00; //Initialize the timer2 counter register to 0
    OCR0 = value;

    init_adc();

    sei(); //enable the interrupt


    ADCSRA |= (1 << ADSC);

    while(1)
    {

    }
    // Should never be reached
    return 0;
}
